import React, { useState, useRef, useEffect } from 'react'
import { useGameSocket } from './useGameSocket.js'
import GameBoard from './GameBoard.jsx'
import { SURFACE_TURNS, DET_COLORS } from './gameData.js'

const C = {
  bg:'#0d0d0f', surface:'#13151f', border:'#1e2130',
  gold:'#c9a84c', red:'#e85555', blue:'#4ab8e8', green:'#5ec77f',
  text:'#e8e4dc', muted:'#55586a'
}

const TC = { taxi:'#f5c518', bus:'#4ab8e8', underground:'#e84545', black:'#aaaaaa', double:'#5ec77f' }

// Determine WS URL: in production use same host, in dev use localhost:3001
const WS_URL = (() => {
  if (typeof window === 'undefined') return 'ws://localhost:3001'
  const host = window.location.host
  // If running on localhost dev, connect to local server
  if (host.includes('localhost') || host.includes('127.0.0.1')) return 'ws://localhost:3001'
  // Production: same host but ws protocol, server runs on same domain via proxy/tunnel
  const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:'
  return `${proto}//${host}`
})()

// ── Home screen ────────────────────────────────────────────────────────────
function HomeScreen({ connected, onCreate, onJoin, lastError }) {
  const [name, setName] = useState('')
  const [code, setCode] = useState('')
  const [mode, setMode] = useState('choose')

  return (
    <div style={s.center}>
      <div style={s.card}>
        {/* Logo */}
        <div style={{display:'flex',gap:18,alignItems:'center',marginBottom:32}}>
          <div style={s.logoBox}>X</div>
          <div>
            <div style={{fontFamily:'Playfair Display,serif',fontSize:24,fontWeight:900,color:C.text}}>Scotland Yard</div>
            <div style={{fontFamily:'DM Mono,monospace',fontSize:11,color:C.muted,letterSpacing:'0.1em',marginTop:2}}>THE HUNT FOR MR. X</div>
          </div>
        </div>

        {/* Connection dot */}
        <div style={{display:'flex',alignItems:'center',gap:6,marginBottom:20}}>
          <div style={{width:7,height:7,borderRadius:'50%',background:connected?C.green:'#555'}}/>
          <span style={{fontSize:11,color:C.muted,fontFamily:'DM Mono'}}>
            {connected?'Server connected':'Connecting...'}
          </span>
        </div>

        {mode==='choose' && (
          <div style={{display:'flex',flexDirection:'column',gap:10,width:'100%'}}>
            <button style={s.btn} onClick={()=>setMode('create')}>Create Room</button>
            <button style={{...s.btn,background:'transparent',border:`2px solid ${C.gold}`,color:C.gold}}
              onClick={()=>setMode('join')}>Join Room</button>
          </div>
        )}

        {(mode==='create'||mode==='join') && (
          <div style={{width:'100%',display:'flex',flexDirection:'column',gap:10}}>
            <input style={s.input} placeholder="Your name" value={name}
              onChange={e=>setName(e.target.value)} maxLength={20} autoFocus/>
            {mode==='join' && (
              <input style={{...s.input,textTransform:'uppercase',letterSpacing:'0.15em',fontFamily:'DM Mono,monospace'}}
                placeholder="Room code  e.g. WOLF-42"
                value={code} onChange={e=>setCode(e.target.value.toUpperCase())} maxLength={10}/>
            )}
            <button style={{...s.btn,opacity:name.trim()?1:0.4}}
              disabled={!name.trim()}
              onClick={()=> mode==='create' ? onCreate(name.trim()) : onJoin(code.trim(),name.trim())}>
              {mode==='create'?'Create & Enter':'Join Game'}
            </button>
            <button style={s.link} onClick={()=>setMode('choose')}>← Back</button>
          </div>
        )}

        {lastError && <div style={{color:C.red,fontSize:12,marginTop:8,fontFamily:'DM Mono'}}>{lastError}</div>}

        <div style={{marginTop:20,color:C.muted,fontSize:12,textAlign:'center',lineHeight:1.8}}>
          2–6 players · One is Mr. X, rest are detectives<br/>
          Mr. X hides across London for 24 turns
        </div>
      </div>
    </div>
  )
}

// ── Lobby screen ───────────────────────────────────────────────────────────
function LobbyScreen({ roomCode, players, myId, isHost, myPlayer, onSetRole, onStart, onChat, chat }) {
  const [msg, setMsg] = useState('')
  const chatRef = useRef(null)
  useEffect(()=>{ if(chatRef.current) chatRef.current.scrollTop=99999 }, [chat])

  const hasMrx = players.some(p=>p.role==='mrx')
  const hasDetective = players.some(p=>p.role==='detective')
  const canStart = isHost && hasMrx && hasDetective && players.length >= 2

  return (
    <div style={{width:'100%',height:'100%',display:'flex',background:C.bg,overflow:'hidden'}}>
      {/* Left panel */}
      <div style={{width:300,minWidth:280,padding:24,background:C.surface,borderRight:`1px solid ${C.border}`,overflowY:'auto',display:'flex',flexDirection:'column',gap:4}}>
        {/* Room code */}
        <div style={{background:C.bg,borderRadius:12,padding:'16px 20px',border:`1px solid ${C.border}`,marginBottom:16,textAlign:'center'}}>
          <div style={{color:C.muted,fontFamily:'DM Mono',fontSize:10,letterSpacing:'0.15em',marginBottom:4}}>ROOM CODE — SHARE THIS</div>
          <div style={{fontFamily:'DM Mono',fontSize:32,fontWeight:700,color:C.gold,letterSpacing:'0.2em'}}>{roomCode}</div>
          <button style={{...s.link,fontSize:11,marginTop:6}} onClick={()=>navigator.clipboard?.writeText(roomCode)}>
            📋 Copy code
          </button>
        </div>

        <div style={s.label}>Players ({players.length}/6)</div>
        {players.map((p,i)=>(
          <div key={p.id} style={{display:'flex',alignItems:'center',gap:10,padding:'8px 10px',background:C.bg,borderRadius:8,marginBottom:3}}>
            <div style={{width:30,height:30,borderRadius:'50%',background:DET_COLORS[i]+'33',
              border:`2px solid ${DET_COLORS[i]}`,display:'flex',alignItems:'center',
              justifyContent:'center',fontSize:13,fontWeight:700,color:DET_COLORS[i],flexShrink:0}}>
              {p.name[0]?.toUpperCase()}
            </div>
            <div style={{flex:1,minWidth:0}}>
              <div style={{fontSize:13,fontWeight:600,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>
                {p.name}{p.id===myId?' (you)':''}{p.id===players[0]?.id?' 👑':''}
              </div>
            </div>
            <div style={{fontSize:11,fontFamily:'DM Mono',padding:'3px 8px',borderRadius:5,
              background:p.role==='mrx'?C.red+'22':p.role==='detective'?C.blue+'22':'transparent',
              color:p.role==='mrx'?C.red:p.role==='detective'?C.blue:C.muted,
              border:`1px solid ${p.role==='mrx'?C.red+'44':p.role==='detective'?C.blue+'44':'transparent'}`,
              flexShrink:0}}>
              {p.role==='mrx'?'MR. X':p.role==='detective'?'DET.':'—'}
            </div>
          </div>
        ))}

        {myPlayer && (
          <div style={{marginTop:16}}>
            <div style={s.label}>Your Role</div>
            <div style={{display:'flex',gap:8,marginBottom:12}}>
              <button style={{...s.roleBtn, border:`2px solid ${myPlayer.role==='mrx'?C.red:C.border}`,
                background:myPlayer.role==='mrx'?C.red+'22':'transparent',
                color:myPlayer.role==='mrx'?C.red:C.muted}}
                onClick={()=>onSetRole('mrx')}>🕵️ Mr. X</button>
              <button style={{...s.roleBtn, border:`2px solid ${myPlayer.role==='detective'?C.blue:C.border}`,
                background:myPlayer.role==='detective'?C.blue+'22':'transparent',
                color:myPlayer.role==='detective'?C.blue:C.muted}}
                onClick={()=>onSetRole('detective')}>🔍 Detective</button>
            </div>

            {isHost ? (
              <button style={{...s.btn,width:'100%',opacity:canStart?1:0.35}} disabled={!canStart} onClick={onStart}>
                {!canStart ? (players.length<2?'Need 2+ players':!hasMrx?'Nobody is Mr. X':!hasDetective?'Need a detective':'Start') : '▶  Start Game'}
              </button>
            ) : (
              <div style={{color:C.muted,fontSize:12,textAlign:'center',padding:'10px 0',fontFamily:'DM Mono'}}>
                Waiting for host to start…
              </div>
            )}
          </div>
        )}
      </div>

      {/* Right: chat */}
      <div style={{flex:1,padding:24,display:'flex',flexDirection:'column',gap:12}}>
        <div style={s.label}>Chat</div>
        <div ref={chatRef} style={{flex:1,overflowY:'auto',background:C.bg,borderRadius:10,
          border:`1px solid ${C.border}`,padding:'12px 14px',minHeight:80}}>
          {chat.length===0 && <div style={{color:C.muted,fontSize:12}}>No messages yet…</div>}
          {chat.map((m,i)=>(
            <div key={i} style={{marginBottom:5}}>
              <span style={{color:C.gold,fontSize:11,fontFamily:'DM Mono'}}>{m.name}: </span>
              <span style={{fontSize:13}}>{m.text}</span>
            </div>
          ))}
        </div>
        <div style={{display:'flex',gap:8}}>
          <input style={{...s.input,flex:1,padding:'9px 13px',fontSize:13}} placeholder="Message…" value={msg}
            onChange={e=>setMsg(e.target.value)}
            onKeyDown={e=>{if(e.key==='Enter'&&msg.trim()){onChat(msg.trim());setMsg('')}}}/>
          <button style={s.sendBtn} onClick={()=>{if(msg.trim()){onChat(msg.trim());setMsg('')}}}>→</button>
        </div>

        {/* How to play mini guide */}
        <div style={{background:C.surface,border:`1px solid ${C.border}`,borderRadius:10,padding:'14px 16px',fontSize:12,color:C.muted,lineHeight:1.9}}>
          <div style={{color:C.text,fontWeight:600,marginBottom:6}}>How to play</div>
          <div>🕵️ <b style={{color:C.text}}>Mr. X</b> — moves in secret across London using taxi/bus/tube. Must survive 24 rounds.</div>
          <div>🔍 <b style={{color:C.text}}>Detectives</b> — work together to land on Mr. X's station and catch him.</div>
          <div>👁 Mr. X must <b style={{color:C.text}}>reveal his position</b> on turns 3, 8, 13, 18, 24.</div>
          <div>⬛ Mr. X has <b style={{color:C.text}}>black tickets</b> that hide which transport he used.</div>
          <div>✕2 Mr. X has <b style={{color:C.text}}>2 double-move tickets</b> to move twice in one turn.</div>
        </div>
      </div>
    </div>
  )
}

// ── HUD overlay (during game) ──────────────────────────────────────────────
function HUD({ gameState, myId, isMyTurn, onDouble, onSkip, validMoves, notifications }) {
  const isMrx = gameState?.mrx?.id === myId
  const myDet = gameState?.detectives?.find(d=>d.id===myId)
  const tk = isMrx ? gameState?.mrx?.tickets : myDet?.tickets
  const { turn, subPhase, mrx, detectives, pendingDouble } = gameState||{}
  const isSurface = SURFACE_TURNS.includes(turn)
  const activeDet = detectives?.[gameState?.detectiveTurn]

  return (
    <>
      {/* Top bar */}
      <div style={{position:'absolute',top:0,left:0,right:0,height:46,background:'#080a10ee',
        backdropFilter:'blur(12px)',borderBottom:`1px solid ${C.border}`,
        display:'flex',alignItems:'center',justifyContent:'space-between',padding:'0 14px',zIndex:50}}>

        <div style={{display:'flex',alignItems:'center',gap:10}}>
          <div style={{fontFamily:'Playfair Display,serif',fontWeight:700,fontSize:16,color:C.text}}>Scotland Yard</div>
          <div style={{fontFamily:'DM Mono',fontSize:11,
            color:isSurface?C.gold:C.muted,
            background:isSurface?C.gold+'20':C.surface,
            border:`1px solid ${isSurface?C.gold+'44':C.border}`,
            padding:'3px 10px',borderRadius:6}}>
            Turn {turn}/24{isSurface?' 👁 SURFACE!':''}
          </div>
        </div>

        {/* Surface turn indicator dots */}
        <div style={{display:'flex',gap:5}}>
          {SURFACE_TURNS.map(t=>(
            <div key={t} style={{width:22,height:22,borderRadius:5,display:'flex',alignItems:'center',
              justifyContent:'center',fontSize:8,fontFamily:'DM Mono',
              background:t<turn?'#ffffff10':t===turn?C.gold:'#0d0f14',
              border:`1px solid ${t<=turn?C.gold+'88':'#1e2130'}`,
              color:t<turn?'#444':t===turn?'#000':'#333'}}>
              {t}
            </div>
          ))}
        </div>

        <div style={{fontSize:12,fontFamily:'DM Mono',
          color:isMyTurn?C.green:C.muted}}>
          {isMyTurn ? '▶ YOUR TURN' : `Waiting: ${subPhase==='mrx'?mrx?.name:activeDet?.name||'...'}`}
        </div>
      </div>

      {/* Ticket strip (bottom-left) */}
      <div style={{position:'absolute',bottom:0,left:0,padding:'10px 12px',
        background:'#080a10ee',backdropFilter:'blur(10px)',
        borderTop:`1px solid ${C.border}`,borderTopRightRadius:10,
        display:'flex',gap:8,alignItems:'center',zIndex:50}}>
        {isMrx ? <>
          <Chip color={TC.taxi} val={tk?.taxi}>🚕</Chip>
          <Chip color={TC.bus} val={tk?.bus}>🚌</Chip>
          <Chip color={TC.underground} val={tk?.underground}>🚇</Chip>
          <Chip color={TC.black} val={tk?.black}>⬛</Chip>
          <Chip color={TC.double} val={tk?.double}>✕2</Chip>
        </> : <>
          <Chip color={TC.taxi} val={tk?.taxi}>🚕</Chip>
          <Chip color={TC.bus} val={tk?.bus}>🚌</Chip>
          <Chip color={TC.underground} val={tk?.underground}>🚇</Chip>
        </>}

        {isMrx && isMyTurn && !pendingDouble && tk?.double>0 && (
          <button onClick={onDouble} style={s.actionBtn('#5ec77f')}>Use ✕2 Move</button>
        )}
        {isMyTurn && validMoves.length===0 && (
          <button onClick={onSkip} style={s.actionBtn('#555')}>Skip (stuck)</button>
        )}
        {pendingDouble && (
          <div style={{fontFamily:'DM Mono',fontSize:11,color:TC.double}}>Double move — pick 2nd station</div>
        )}
      </div>

      {/* Right panel */}
      <div style={{position:'absolute',top:54,right:0,width:200,background:'#080a10ee',
        backdropFilter:'blur(10px)',borderLeft:`1px solid ${C.border}`,
        padding:'14px 14px',zIndex:50,maxHeight:'calc(100%-54px)',overflowY:'auto'}}>

        {isMrx ? (
          <>
            <div style={s.label}>Your Move Log</div>
            {mrx.log.length===0 && <div style={{color:C.muted,fontSize:11,fontFamily:'DM Mono'}}>No moves yet</div>}
            {[...mrx.log].reverse().slice(0,12).map((e,i)=>(
              <div key={i} style={{display:'flex',gap:6,alignItems:'center',marginBottom:5}}>
                <span style={{color:C.muted,fontFamily:'DM Mono',fontSize:9,minWidth:14}}>t{e.turn}</span>
                <span style={{fontSize:12}}>{e.transport==='taxi'?'🚕':e.transport==='bus'?'🚌':e.transport==='underground'?'🚇':e.transport==='ferry'?'⛵':'⬛'}</span>
                <span style={{fontFamily:'DM Mono',fontSize:11,color:e.revealed?C.gold:'#333'}}>
                  {e.revealed ? `→ ${e.pos} 👁` : '???'}
                </span>
              </div>
            ))}
          </>
        ) : (
          <>
            <div style={s.label}>Detectives</div>
            {detectives?.map((d,i)=>(
              <div key={d.id} style={{display:'flex',alignItems:'center',gap:6,marginBottom:6}}>
                <div style={{width:7,height:7,borderRadius:'50%',background:d.color,flexShrink:0}}/>
                <span style={{fontSize:11,color:d.id===myId?C.text:C.muted,flex:1,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{d.name}</span>
                <span style={{fontFamily:'DM Mono',fontSize:9,color:'#333'}}>#{d.pos}</span>
              </div>
            ))}

            <div style={{borderTop:`1px solid ${C.border}`,paddingTop:10,marginTop:10}}>
              <div style={s.label}>Mr. X Sightings</div>
              {mrx?.lastSeen ? (
                <div style={{fontFamily:'DM Mono',fontSize:12,color:C.red}}>
                  Station {mrx.lastSeen}<br/>
                  <span style={{fontSize:10,color:'#555'}}>seen turn {mrx.lastSeenTurn}</span>
                </div>
              ) : (
                <div style={{fontFamily:'DM Mono',fontSize:11,color:'#333'}}>Not surfaced yet</div>
              )}
            </div>

            <div style={{borderTop:`1px solid ${C.border}`,paddingTop:10,marginTop:10}}>
              <div style={s.label}>Mr. X Transport Log</div>
              <div style={{display:'flex',flexWrap:'wrap',gap:4}}>
                {mrx?.log?.map((e,i)=>(
                  <div key={i} style={{background:'#0d0f14',border:`1px solid ${C.border}`,
                    borderRadius:4,padding:'2px 6px',fontFamily:'DM Mono',fontSize:9,
                    display:'flex',gap:3,alignItems:'center'}}>
                    <span style={{color:'#444'}}>t{e.turn}</span>
                    <span>{e.transport==='taxi'?'🚕':e.transport==='bus'?'🚌':e.transport==='underground'?'🚇':e.transport==='ferry'?'⛵':'⬛'}</span>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </div>

      {/* Notifications */}
      <div style={{position:'absolute',top:54,left:'50%',transform:'translateX(-50%)',
        zIndex:200,display:'flex',flexDirection:'column',gap:5,alignItems:'center',pointerEvents:'none'}}>
        {notifications.map(n=>(
          <div key={n.id} style={{padding:'7px 16px',borderRadius:7,fontSize:12,
            background:n.kind==='error'?'#cc222233':n.kind==='mrx'?C.gold+'22':C.surface,
            border:`1px solid ${n.kind==='error'?C.red:n.kind==='mrx'?C.gold:C.border}`,
            color:n.kind==='error'?'#ff6666':n.kind==='mrx'?C.gold:C.text,
            fontFamily:'DM Mono',backdropFilter:'blur(8px)'}}>
            {n.text}
          </div>
        ))}
      </div>
    </>
  )
}

function Chip({color,val,children}) {
  return (
    <div style={{display:'flex',alignItems:'center',gap:5,padding:'5px 9px',borderRadius:7,
      background:val>0?color+'1a':'#ffffff0a',
      border:`1px solid ${val>0?color+'55':'#1a1a1a'}`,
      fontFamily:'DM Mono',fontSize:12,color:val>0?color:'#333'}}>
      {children} {val}
    </div>
  )
}

// ── End screen ─────────────────────────────────────────────────────────────
function EndScreen({ result, gameState, myId, isHost, onRestart }) {
  const isMrxWin = result?.winner==='mrx'
  const isMrx = gameState?.mrx?.id===myId
  const iWon = (isMrxWin&&isMrx)||(!isMrxWin&&!isMrx)

  return (
    <div style={{...s.center,position:'absolute',inset:0,background:'#000000aa',zIndex:300}}>
      <div style={{...s.card,maxWidth:440,textAlign:'center'}}>
        <div style={{fontSize:56,marginBottom:12}}>{isMrxWin?'🕵️':'🔍'}</div>
        <div style={{fontFamily:'Playfair Display,serif',fontSize:26,fontWeight:900,
          color:isMrxWin?C.red:C.blue,marginBottom:6}}>
          {isMrxWin?'Mr. X Escapes!':'Detectives Win!'}
        </div>
        <div style={{color:C.muted,fontSize:13,marginBottom:20}}>{result?.reason}</div>
        {result?.mrxFinalPos && (
          <div style={{background:C.bg,border:`1px solid ${C.border}`,borderRadius:8,
            padding:'10px 16px',marginBottom:18,fontFamily:'DM Mono',fontSize:13}}>
            Mr. X was at station <span style={{color:C.gold,fontSize:18,fontWeight:700}}>{result.mrxFinalPos}</span>
          </div>
        )}
        <div style={{fontSize:20,fontWeight:700,color:iWon?C.green:C.muted,marginBottom:24}}>
          {iWon?'🎉 You won!':'💀 You lost'}
        </div>
        {isHost
          ? <button style={{...s.btn,width:'100%'}} onClick={onRestart}>Play Again</button>
          : <div style={{color:C.muted,fontSize:12}}>Waiting for host to restart…</div>
        }
      </div>
    </div>
  )
}

// ── Chat overlay (during game) ─────────────────────────────────────────────
function ChatOverlay({ chat, onChat }) {
  const [open, setOpen] = useState(false)
  const [msg, setMsg] = useState('')
  const ref = useRef(null)
  useEffect(()=>{ if(ref.current) ref.current.scrollTop=99999 }, [chat, open])

  return (
    <>
      <button onClick={()=>setOpen(v=>!v)} style={{position:'absolute',bottom:52,right:8,
        padding:'7px 12px',borderRadius:9,background:C.surface,border:`1px solid ${C.border}`,
        color:C.text,cursor:'pointer',fontSize:15,zIndex:60}}>
        💬
      </button>
      {open && (
        <div style={{position:'absolute',bottom:90,right:8,width:250,
          background:'#0d0f14f0',backdropFilter:'blur(12px)',
          border:`1px solid ${C.border}`,borderRadius:12,
          padding:12,display:'flex',flexDirection:'column',gap:8,
          maxHeight:280,zIndex:60}}>
          <div ref={ref} style={{flex:1,overflowY:'auto',minHeight:80}}>
            {chat.length===0&&<div style={{color:C.muted,fontSize:11}}>No messages</div>}
            {chat.map((m,i)=>(
              <div key={i} style={{marginBottom:4}}>
                <span style={{color:C.gold,fontSize:10,fontFamily:'DM Mono'}}>{m.name}: </span>
                <span style={{fontSize:12}}>{m.text}</span>
              </div>
            ))}
          </div>
          <div style={{display:'flex',gap:6}}>
            <input style={{...s.input,flex:1,padding:'7px 10px',fontSize:12}} placeholder="Message…"
              value={msg} onChange={e=>setMsg(e.target.value)}
              onKeyDown={e=>{if(e.key==='Enter'&&msg.trim()){onChat(msg.trim());setMsg('')}}}/>
            <button style={s.sendBtn} onClick={()=>{if(msg.trim()){onChat(msg.trim());setMsg('')}}}>→</button>
          </div>
        </div>
      )}
    </>
  )
}

// ── Main App ───────────────────────────────────────────────────────────────
export default function App() {
  const g = useGameSocket(WS_URL)
  const [lastError, setLastError] = useState(null)

  useEffect(()=>{
    const err = g.notifications.find(n=>n.kind==='error')
    if(err) setLastError(err.text)
  },[g.notifications])

  if (g.phase==='home') {
    return <HomeScreen connected={g.connected} onCreate={g.createRoom} onJoin={g.joinRoom} lastError={lastError}/>
  }

  if (g.phase==='lobby') {
    return (
      <LobbyScreen
        roomCode={g.roomCode} players={g.players} myId={g.myId}
        isHost={g.isHost} myPlayer={g.myPlayer}
        onSetRole={g.setRole} onStart={g.startGame}
        onChat={g.sendChat} chat={g.chat}
      />
    )
  }

  return (
    <div style={{position:'relative',width:'100%',height:'100%',overflow:'hidden'}}>
      {g.gameState && (
        <GameBoard
          gameState={g.gameState} validMoves={g.validMoves}
          isMyTurn={g.isMyTurn} myId={g.myId} onMove={g.makeMove}
        />
      )}
      {g.gameState && (
        <HUD
          gameState={g.gameState} myId={g.myId} isMyTurn={g.isMyTurn}
          onDouble={g.useDouble} onSkip={g.skipTurn}
          validMoves={g.validMoves} notifications={g.notifications}
        />
      )}
      <ChatOverlay chat={g.chat} onChat={g.sendChat}/>
      {g.phase==='ended' && (
        <EndScreen result={g.gameResult} gameState={g.gameState}
          myId={g.myId} isHost={g.isHost} onRestart={g.restart}/>
      )}
    </div>
  )
}

// ── Shared styles ──────────────────────────────────────────────────────────
const s = {
  center: { width:'100%',height:'100%',display:'flex',alignItems:'center',justifyContent:'center',background:C.bg },
  card: { background:C.surface,border:`1px solid ${C.border}`,borderRadius:18,padding:'44px 38px',
    width:'100%',maxWidth:400,display:'flex',flexDirection:'column',alignItems:'center' },
  logoBox: { width:58,height:58,borderRadius:14,
    background:'linear-gradient(135deg,#6b1010,#c42020)',
    display:'flex',alignItems:'center',justifyContent:'center',
    fontSize:30,fontFamily:'Playfair Display,serif',fontWeight:900,color:'#fff',
    boxShadow:'0 0 28px #c4202055',flexShrink:0 },
  btn: { padding:'13px 22px',background:'linear-gradient(135deg,#7a1010,#c03030)',
    border:'none',borderRadius:10,color:'#fff',fontSize:15,fontWeight:600,
    cursor:'pointer',width:'100%',fontFamily:'DM Sans,sans-serif' },
  input: { width:'100%',padding:'12px 14px',background:'#080a10',
    border:`1px solid ${C.border}`,borderRadius:9,color:C.text,
    fontSize:14,outline:'none' },
  link: { background:'none',border:'none',color:C.muted,cursor:'pointer',
    fontSize:13,fontFamily:'DM Sans,sans-serif',padding:'4px 0' },
  label: { fontFamily:'DM Mono,monospace',fontSize:10,letterSpacing:'0.15em',
    color:C.muted,textTransform:'uppercase',marginBottom:6,marginTop:6 },
  roleBtn: { flex:1,padding:'10px 10px',borderRadius:8,cursor:'pointer',
    fontSize:13,fontFamily:'DM Sans,sans-serif',fontWeight:500 },
  sendBtn: { padding:'9px 14px',background:C.gold+'22',border:`1px solid ${C.gold}`,
    color:C.gold,borderRadius:8,cursor:'pointer',fontSize:16 },
  actionBtn: (col) => ({
    padding:'6px 12px',borderRadius:7,background:col+'22',
    border:`1px solid ${col}`,color:col,cursor:'pointer',
    fontFamily:'DM Sans,sans-serif',fontSize:12
  })
}
