import React, { useState, useRef, useEffect, useCallback } from 'react'
import { STATION_POSITIONS, RAW_CONNECTIONS, UNDERGROUND_STATIONS, SURFACE_TURNS } from './gameData.js'

const TC = { taxi:'#f5c518', bus:'#4ab8e8', underground:'#e84545', ferry:'#4466ff', black:'#aaaaaa' }
const VW = 1000, VH = 620

function sp(id) {
  const [x,y] = STATION_POSITIONS[id]
  return [x, y * (VH/670)]
}

// Pre-compute unique edges
const EDGES = (() => {
  const seen = new Set()
  const out = []
  for (const [a,b,type] of RAW_CONNECTIONS) {
    if (type === 'ferry') continue
    const key = `${Math.min(a,b)}-${Math.max(a,b)}-${type}`
    if (seen.has(key)) continue
    seen.add(key)
    out.push({ a, b, type })
  }
  return out
})()

export default function GameBoard({ gameState, validMoves, isMyTurn, myId, onMove }) {
  const [hovered, setHovered] = useState(null)
  const [picker, setPicker] = useState(null) // {stationId, transports}
  const [pan, setPan] = useState({ x:0, y:0, scale:1 })
  const dragRef = useRef(null)
  const svgRef = useRef(null)

  // Group valid moves by destination
  const validDests = new Map()
  for (const m of validMoves) {
    if (!validDests.has(m.dest)) validDests.set(m.dest, [])
    validDests.get(m.dest).push(m.transport)
  }

  const handleWheel = useCallback((e) => {
    e.preventDefault()
    const delta = e.deltaY < 0 ? 0.12 : -0.12
    setPan(p => ({ ...p, scale: Math.min(6, Math.max(0.4, p.scale + delta)) }))
  }, [])

  useEffect(() => {
    const el = svgRef.current
    if (!el) return
    el.addEventListener('wheel', handleWheel, { passive: false })
    return () => el.removeEventListener('wheel', handleWheel)
  }, [handleWheel])

  const onMouseDown = (e) => {
    if (e.button !== 0) return
    dragRef.current = { sx: e.clientX, sy: e.clientY, px: pan.x, py: pan.y }
  }
  const onMouseMove = (e) => {
    if (!dragRef.current) return
    setPan(p => ({ ...p, x: dragRef.current.px + e.clientX - dragRef.current.sx, y: dragRef.current.py + e.clientY - dragRef.current.sy }))
  }
  const onMouseUp = () => { dragRef.current = null }

  const clickStation = (id, e) => {
    e.stopPropagation()
    if (!isMyTurn) return
    const ts = validDests.get(id)
    if (!ts || ts.length === 0) return
    if (ts.length === 1) { onMove(id, ts[0]); return }
    setPicker({ stationId: id, transports: ts })
  }

  if (!gameState) return null
  const { mrx, detectives } = gameState

  return (
    <div style={{ position:'relative', width:'100%', height:'100%', background:'#080a10', userSelect:'none' }}>
      <svg ref={svgRef} width="100%" height="100%" viewBox={`0 0 ${VW} ${VH}`}
        style={{ cursor: dragRef.current ? 'grabbing' : 'grab', display:'block' }}
        onMouseDown={onMouseDown} onMouseMove={onMouseMove}
        onMouseUp={onMouseUp} onMouseLeave={onMouseUp}>
        <defs>
          <filter id="glow"><feGaussianBlur stdDeviation="3" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
          <filter id="glow2"><feGaussianBlur stdDeviation="5" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
          <radialGradient id="bg" cx="50%" cy="50%" r="60%">
            <stop offset="0%" stopColor="#0e1220"/>
            <stop offset="100%" stopColor="#060810"/>
          </radialGradient>
        </defs>

        <g transform={`translate(${pan.x},${pan.y}) scale(${pan.scale})`} style={{transformOrigin:'0 0'}}>
          <rect width={VW} height={VH} fill="url(#bg)"/>

          {/* Grid dots for atmosphere */}
          {Array.from({length:80},(_,i)=>(
            <circle key={i} cx={(i%10)*110+55} cy={Math.floor(i/10)*70+35} r={0.6} fill="#ffffff06"/>
          ))}

          {/* Transport edges */}
          {EDGES.map(({a,b,type})=>{
            const [ax,ay]=sp(a), [bx,by]=sp(b)
            const isU = type==='underground'
            const isB = type==='bus'
            return (
              <line key={`${a}-${b}-${type}`}
                x1={ax} y1={ay} x2={bx} y2={by}
                stroke={TC[type]}
                strokeWidth={isU?2.2:isB?1.6:1.0}
                strokeOpacity={isU?0.55:isB?0.45:0.3}
                strokeDasharray={isU?'7 4':'none'}
              />
            )
          })}

          {/* Valid move rings */}
          {Array.from(validDests.keys()).map(id=>{
            const [x,y]=sp(id)
            return (
              <g key={`vm-${id}`}>
                <circle cx={x} cy={y} r={16} fill={`${TC.taxi}18`} stroke={TC.taxi} strokeWidth={1.5} opacity={0.9}/>
                <circle cx={x} cy={y} r={20} fill="none" stroke={`${TC.taxi}44`} strokeWidth={1}/>
              </g>
            )
          })}

          {/* Stations */}
          {Array.from({length:199},(_,i)=>i+1).map(id=>{
            const [x,y]=sp(id)
            const isU = UNDERGROUND_STATIONS.has(id)
            const isValid = validDests.has(id)
            const isHov = hovered===id
            const r = isU ? 5.5 : 4
            return (
              <g key={id} style={{cursor:isValid?'pointer':'default'}}
                onMouseEnter={()=>setHovered(id)} onMouseLeave={()=>setHovered(null)}
                onClick={e=>clickStation(id,e)}>
                {isValid && <circle cx={x} cy={y} r={15} fill="#f5c51810" stroke="none"/>}
                <circle cx={x} cy={y} r={r}
                  fill={isValid ? '#1e2a50' : isU ? '#2a1a1a' : '#141824'}
                  stroke={isValid ? '#f5c518' : isU ? TC.underground : '#2a3050'}
                  strokeWidth={isValid||isU ? 1.5 : 0.8}
                  filter={isValid?'url(#glow)':'none'}
                />
                {(isHov||isValid) && (
                  <text x={x} y={y-8} textAnchor="middle" fontSize="6.5"
                    fill={isValid?'#f5c518':'#888'} fontFamily="DM Mono,monospace">{id}</text>
                )}
              </g>
            )
          })}

          {/* Mr X last seen ghost */}
          {mrx.lastSeen && mrx.pos===null && (()=>{
            const [x,y]=sp(mrx.lastSeen)
            return (
              <g key="mrx-ghost">
                <circle cx={x} cy={y} r={14} fill="#ff000018" stroke="#ff4444" strokeWidth={1.5} strokeDasharray="4 3"/>
                <text x={x} y={y+4} textAnchor="middle" fontSize="11" fill="#ff5555"
                  fontFamily="Playfair Display,serif" fontWeight="bold">?</text>
                <text x={x} y={y+20} textAnchor="middle" fontSize="5.5" fill="#ff444488"
                  fontFamily="DM Mono,monospace">t{mrx.lastSeenTurn}</text>
              </g>
            )
          })()}

          {/* Mr X actual position */}
          {mrx.pos && (()=>{
            const [x,y]=sp(mrx.pos)
            return (
              <g key="mrx-real" filter="url(#glow2)">
                <circle cx={x} cy={y} r={13} fill="#1a0505" stroke="#cc2222" strokeWidth={2.5}/>
                <text x={x} y={y+4} textAnchor="middle" fontSize="11" fill="#ff3333"
                  fontFamily="Playfair Display,serif" fontWeight="bold">X</text>
              </g>
            )
          })()}

          {/* Detective pieces */}
          {detectives.map((det,i)=>{
            const [x,y]=sp(det.pos)
            return (
              <g key={det.id} filter="url(#glow)">
                <circle cx={x} cy={y} r={9} fill="#060810" stroke={det.color} strokeWidth={2.5}/>
                <text x={x} y={y+3.5} textAnchor="middle" fontSize="7.5" fill={det.color}
                  fontFamily="DM Mono,monospace" fontWeight="500">{i+1}</text>
              </g>
            )
          })}
        </g>
      </svg>

      {/* Legend */}
      <div style={{position:'absolute',bottom:8,left:10,display:'flex',gap:14,alignItems:'center',pointerEvents:'none'}}>
        {[['taxi','🚕 Taxi'],['bus','🚌 Bus'],['underground','🚇 Tube']].map(([t,l])=>(
          <div key={t} style={{display:'flex',gap:5,alignItems:'center'}}>
            <div style={{width:18,height:2.5,background:TC[t],borderRadius:2,opacity:0.8}}/>
            <span style={{fontSize:9,color:'#555',fontFamily:'DM Mono',textTransform:'uppercase'}}>{l}</span>
          </div>
        ))}
        <span style={{fontSize:9,color:'#333',fontFamily:'DM Mono'}}>scroll=zoom · drag=pan</span>
      </div>

      {/* Transport picker */}
      {picker && (
        <div style={{position:'absolute',inset:0,background:'#00000090',display:'flex',alignItems:'center',justifyContent:'center',zIndex:100}}
          onClick={()=>setPicker(null)}>
          <div style={{background:'#13151f',border:'1px solid #2a2d40',borderRadius:14,padding:'24px 28px',minWidth:220}}
            onClick={e=>e.stopPropagation()}>
            <div style={{color:'#666',fontFamily:'DM Mono',fontSize:11,letterSpacing:'0.12em',marginBottom:14}}>
              MOVE TO STATION {picker.stationId}
            </div>
            {picker.transports.map(t=>(
              <button key={t} onClick={()=>{onMove(picker.stationId,t);setPicker(null)}}
                style={{display:'block',width:'100%',marginBottom:8,padding:'11px 16px',
                  borderRadius:9,border:`2px solid ${TC[t]}`,background:`${TC[t]}18`,
                  color:TC[t],cursor:'pointer',fontFamily:'DM Mono',fontSize:13,
                  textTransform:'uppercase',letterSpacing:'0.1em',textAlign:'left'}}>
                {t==='taxi'?'🚕':t==='bus'?'🚌':t==='underground'?'🚇':t==='black'?'⬛':'⛵'} {t==='black'?'Black Ticket':t}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
