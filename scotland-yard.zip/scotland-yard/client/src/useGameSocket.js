import { useState, useEffect, useRef, useCallback } from 'react'

function genId() {
  return 'p_' + Math.random().toString(36).slice(2, 10)
}

export function useGameSocket(wsUrl) {
  const [connected, setConnected] = useState(false)
  const [roomCode, setRoomCode] = useState(null)
  const [players, setPlayers] = useState([])
  const [gameState, setGameState] = useState(null)
  const [validMoves, setValidMoves] = useState([])
  const [isMyTurn, setIsMyTurn] = useState(false)
  const [chat, setChat] = useState([])
  const [phase, setPhase] = useState('home')
  const [gameResult, setGameResult] = useState(null)
  const [notifications, setNotifications] = useState([])
  const [error, setError] = useState(null)

  const [myId] = useState(() => {
    let id = sessionStorage.getItem('sy_pid')
    if (!id) { id = genId(); sessionStorage.setItem('sy_pid', id) }
    return id
  })
  const [myName, setMyName] = useState(() => sessionStorage.getItem('sy_name') || '')

  const wsRef = useRef(null)
  const retryRef = useRef(null)

  const addNotif = useCallback((text, kind = 'info') => {
    const id = Date.now() + Math.random()
    setNotifications(p => [...p.slice(-4), { id, text, kind }])
    setTimeout(() => setNotifications(p => p.filter(n => n.id !== id)), 4000)
  }, [])

  const connect = useCallback(() => {
    if (wsRef.current) { try { wsRef.current.close() } catch(e){} }
    const ws = new WebSocket(wsUrl)
    wsRef.current = ws

    ws.onopen = () => { setConnected(true); setError(null) }
    ws.onclose = () => {
      setConnected(false)
      retryRef.current = setTimeout(connect, 3000)
    }
    ws.onerror = () => setError('Connecting...')

    ws.onmessage = (e) => {
      let msg; try { msg = JSON.parse(e.data) } catch { return }
      switch (msg.type) {
        case 'room_created':
          setRoomCode(msg.code); setPlayers(msg.players); setPhase('lobby'); break
        case 'room_joined':
          setRoomCode(msg.code); setPlayers(msg.players); setPhase('lobby')
          if (msg.chat) setChat(msg.chat); break
        case 'player_joined':
          setPlayers(msg.players)
          addNotif(`${msg.players[msg.players.length-1]?.name} joined`); break
        case 'players_updated':
          setPlayers(msg.players); break
        case 'game_started':
          setPhase('game'); setGameResult(null); break
        case 'game_state':
          setGameState(msg.state); setValidMoves(msg.validMoves||[]); setIsMyTurn(!!msg.isMyTurn); break
        case 'mrx_moved':
          addNotif(`Mr. X used ${msg.transport.toUpperCase()} — turn ${msg.turn}`, 'mrx'); break
        case 'game_ended':
          setGameResult(msg); setPhase('ended'); break
        case 'game_reset':
          setPlayers(msg.players); setGameState(null); setValidMoves([])
          setIsMyTurn(false); setGameResult(null); setPhase('lobby'); break
        case 'player_disconnected':
          setPlayers(msg.players); addNotif('A player disconnected', 'warn'); break
        case 'chat':
          setChat(p => [...p.slice(-199), msg]); break
        case 'error':
          addNotif(msg.message, 'error'); break
      }
    }
  }, [wsUrl, addNotif])

  useEffect(() => {
    connect()
    return () => { clearTimeout(retryRef.current); try { wsRef.current?.close() } catch(e){} }
  }, [connect])

  const send = useCallback((obj) => {
    if (wsRef.current?.readyState === 1) wsRef.current.send(JSON.stringify(obj))
  }, [])

  const createRoom = useCallback((name) => {
    sessionStorage.setItem('sy_name', name); setMyName(name)
    send({ type: 'create_room', playerId: myId, name })
  }, [send, myId])

  const joinRoom = useCallback((code, name) => {
    sessionStorage.setItem('sy_name', name); setMyName(name)
    send({ type: 'join_room', code: code.toUpperCase(), playerId: myId, name })
  }, [send, myId])

  const isHost = players.length > 0 && players[0]?.id === myId
  const myPlayer = players.find(p => p.id === myId)

  return {
    connected, roomCode, players, gameState, validMoves, isMyTurn,
    myId, myName, chat, phase, gameResult, notifications, error,
    isHost, myPlayer,
    createRoom,
    joinRoom,
    setRole: (role) => send({ type: 'set_role', role }),
    startGame: () => send({ type: 'start_game' }),
    makeMove: (dest, transport) => send({ type: 'move', dest, transport }),
    useDouble: () => send({ type: 'use_double' }),
    skipTurn: () => send({ type: 'skip_turn' }),
    sendChat: (text) => send({ type: 'chat', text }),
    restart: () => send({ type: 'restart' }),
  }
}
